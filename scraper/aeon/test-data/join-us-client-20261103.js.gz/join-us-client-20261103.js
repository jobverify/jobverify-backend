﻿$(document).ready(function () {






    var frmValdationInstance = $('#frmResume').parsley({
        uiEnabled: true,
        errorClass: 'error',
        successClass: 'success',
        errorsWrapper: '<div class="parsley-error-list"></div>',
        errorTemplate: '<label class="error"></li>'
    });

    $(".btnshowhide1").click(function () {
        $(".hidecareer").show();
        $(".btnshowhide2").show();
        $(".btnshowhide1").hide();

    });
    $(".btnshowhide2").click(function () {
        $(".hidecareer").hide();
        $(".btnshowhide2").hide();
        $(".btnshowhide1").show();
    });

    var rm = $(".read_more"),
        moreText = "Read More",
        lessText = "Read More";

    rm.click(function () {
        var $this = $(this);
        if ($this.data('toggle') != 'close') {
            $this.data('toggle', 'close');
            $this.siblings('.ShortJobDiscription').hide();
            $this.siblings('.JobDiscription').show();
        } else {
            $this.data('toggle', 'open');
            $this.siblings('.JobDiscription').hide();
            $this.siblings('.ShortJobDiscription').show();
        }
        //$this.prev().slideToggle();
        //$this.text($this.text() == moreText ? lessText : moreText);

    });

    $('.btnDetail').click(function (e) {
        e.preventDefault();
        clearForm();
        var jobTitle = $(this).attr('data-title');
        var JDID = $(this).attr('data-jdid');
        $('#hfTitle').val(jobTitle);
        $('#hfJDID').val(JDID);
        $('#modal').show();
    });

    $('.modal-header > .close').click(function () {
        $('#modal').hide();
    });

    $('#btnSubmit').click(function (e) {
        e.preventDefault();
        frmValdationInstance.validate({ force: true });

        if (frmValdationInstance.isValid()) {
            var ipFile = $('#fResume').get(0);// input = document.getElementById('fileinput');
            if (ipFile.files.length > 0) {
                for (var i = 0; i < ipFile.files.length; i++) {
                    if (ipFile.files[i].name.split('.')[1].toLowerCase() != "pdf" && ipFile.files[i].name.split('.')[1].toLowerCase() != "doc" && ipFile.files[i].name.split('.')[1].toLowerCase() != "docx") {
                        //$('.contract-form-group1.resume').append('<label class="error">pdf and doc files are only allowed</label>');
                        if ($('.contract-form-group1.resume label.error').get() == 0) {
                            $('.contract-form-group1.resume').append('<label class="error">pdf and doc files are only allowed</label>');
                        } else {
                            $('.contract-form-group1.resume label.error').html('pdf and doc files are only allowed');
                        }
                        return false;
                    }
                }
                if ($('.contract-form-group1.resume label.error').get() != 0) {
                    $('.contract-form-group1.resume label.error').remove();
                }
            } else {
                if ($('.contract-form-group1.resume label.error').get() == 0) {
                    $('.contract-form-group1.resume').append('<label class="error">Please attach resume</label>');
                } else {
                    $('.contract-form-group1.resume label.error').html('Please attach resume');
                }
                return false;
            }

            //var pData = {
            //    Title: $('#hfTitle').val(),
            //    FirstName: $('#txtFirstName').val(),
            //    LastName: $('#txtLastName').val(),
            //    Email: $('#txtEmailId').val(),
            //    MobileNo: $('#txtContactNo').val(),
            //    Message: $('#txtMessage').val()
            //};
            var fuResume = $('#fResume').get(0);
            var fData = new FormData();
            fData.append("JDID", $('#hfJDID').val());
            fData.append("Title", $('#hfTitle').val());
            fData.append("FirstName", $('#txtFirstName').val());
            fData.append("LastName", $('#txtLastName').val());
            fData.append("Email", $('#txtEmailId').val());
            fData.append("MobileNo", $('#txtContactNo').val());
            fData.append("Message", $('#txtMessage').val());
            if (fuResume.files.length > 0) {
                fData.append("File", fuResume.files[0]);
            }
            $('#btnSubmit').html('Submitting <i class="fa fa-circle-o-notch fa-spin" style="font-size:24px"></i>');
            $.ajax({
                url: '/Careers/ApplyJob',
                type: 'post',
                data: fData,
                processData: false,
                contentType: false,
                cache: false,
                success: function (data) {
                    if (data == null) {
                        $('#showMessage').html("<div style='color:#ea4335'>Message not sent. Please try again after some time.</div>");
                    } else {
                        clearForm();
                        $('#showMessage').html("<div style='color:#34a853'>Thank you for contacting.</div>");
                    }
                    $('#btnSubmit').html("Submit");
                },
                error: function (e) {
                    $('#showMessage').html("<div style='color:#ea4335'>Message not sent. Please try again after some time.</div>");
                    $('#btnSubmit').html("Submit");
                }
            });
        }

    });

    //$("#frmResume").validate({
    //    rules:
    //    {
    //        FirstName: {
    //            required: true,
    //        },
    //        LastName: {
    //            required: true,
    //        },
    //        EmailId: {
    //            required: true,
    //            email: true
    //        },
    //        MobileNo: {
    //            required: true,
    //            maxlength: 10,
    //            minlength: 10
    //        },
    //        Message: {
    //            required: false
    //        },
    //        fResume: {
    //            required: true,
    //            extension: "doc|docx|pdf"
    //        }
    //    },
    //    messages:
    //    {
    //        FirstName: {
    //            required: "Please enter your first name"
    //        },
    //        LastName: {
    //            required: "Please enter your last name"
    //        },
    //        EmailId: {
    //            required: "Please enter your email id",
    //            email: "Please enter valid email id"
    //        },
    //        MobileNo: {
    //            required: "Please enter your contact number",
    //            maxlength: "Invalid contact number",
    //            minlength: "Invalid contact number"
    //        },
    //        fResume: {
    //            required: "Please attach resume",
    //            extension: "Resumes are accepted in only doc,docx and pdf formats"
    //        }
    //    }
    //});

    function clearForm() {
        $('#hfTitle').val('');
        $('#txtFirstName').val('');
        $('#txtLastName').val('');
        $('#txtEmailId').val('');
        $('#txtContactNo').val('');
        $('#txtMessage').val('');
        var fuResume = $('#fResume');
        fuResume.replaceWith(fuResume.val('').clone(true));
    }
});